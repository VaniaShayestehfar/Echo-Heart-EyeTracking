function analyze_fixation_metrics_with_ROI()
    % Clear workspace and close figures
    clear all; 
    close all; 
    clc;
    
    %% Parameters
    num_trials = 8;
    subjects = {'Kasra', 'Javad', 'Milad', 'MMD', 'MohAli', 'Mohsen', 'Yashar', 'Arsham',...
               'Aliyz', 'Amin', 'Hasti', 'Hosein', 'Karimi', 'Mahdii', 'Mahy', 'Meli',...
               'MhMhd', 'Mitra', 'Mobina', 'Mohamad', 'Most', 'Moti', 'Saba', 'Sheri',...
               'SinFa', 'Telma'};
    
    % File paths
    edfDir = 'E:\EYE_TRACKING_PROJECT\matlab';
    Data_path = 'E:\EYE_TRACKING_PROJECT\matlab\';
    output_folder = 'E:\EYE_TRACKING_PROJECT\matlab\Fixation_Metrics_Analysis\';
    
    % Create output folder if needed
    if ~exist(output_folder, 'dir')
        mkdir(output_folder);
    end

    %% Initialize data storage
    % We'll store data in a 3D matrix: subjects x trials x metrics
    % Metrics: 1=Fixation Count (FC), 2=Average Fixation Duration (AFD), 3=Total Fixation Duration (TFD)
    all_metrics = nan(numel(subjects), num_trials, 3);
    
    % Initialize behavioral data storage
    trial_correctness = nan(numel(subjects), num_trials);
    trial_conf_values = nan(numel(subjects), num_trials);
    trial_RT_values = nan(numel(subjects), num_trials);
    
    %% Load behavioral data
    fprintf('\n==== LOADING BEHAVIORAL DATA ====\n');
    
    files = dir(fullfile(Data_path, '*.mat'));
    for i = 1:numel(files)
        file_path = fullfile(Data_path, files(i).name);
        try
            data_struct = load(file_path);
            
            % Extract subject name
            if isfield(data_struct, 'subName')
                subject_name = data_struct.subName;
            else
                [~, subject_name] = fileparts(files(i).name);
            end
            
            % Find subject index
            s_idx = find(strcmpi(subjects, subject_name));
            if isempty(s_idx)
                continue;
            end
            
            % Extract behavioral data
            if isfield(data_struct, 'resp') && isfield(data_struct, 'conf') && isfield(data_struct, 'RT')
                resp = data_struct.resp;
                conf = data_struct.conf;
                RT = data_struct.RT;
                
                % Process each trial
                for trial = 1:min(num_trials, numel(resp))
                    if trial <= numel(resp) && ~isempty(resp{trial})
                        % Calculate correctness (1=correct, 0=incorrect)
                        % This is a simplified version - adjust based on your actual correctness criteria
                        trial_correctness(s_idx, trial) = ~isempty(find(resp{trial} == correct_ans(trial), 1));
                        
                        % Store confidence
                        if trial <= numel(conf)
                            trial_conf_values(s_idx, trial) = conf(trial);
                        end
                        
                        % Store RT (first response)
                        if trial <= size(RT, 1)
                            trial_RT_values(s_idx, trial) = RT(trial, 1);
                        end
                    end
                end
            end
        catch ME
            warning('Error processing %s: %s', file_path, ME.message);
        end
    end

    %% Process each subject's EDF data
    for s_idx = 1:numel(subjects)
        subject = subjects{s_idx};
        fprintf('\n==== PROCESSING SUBJECT: %s ====\n', subject);
        
        % Load EDF data
        edf_file = fullfile(edfDir, [subject '.edf']);
        if ~exist(edf_file, 'file')
            warning('EDF file not found: %s', edf_file);
            continue;
        end
        
        try
            edf = Edf2Mat(edf_file);
            fixations = edf.Events.Efix;
            fixStarts = [fixations.start];
            fixDurs = [fixations.duration];
            fixX = [fixations.posX];
            fixY = [fixations.posY];
        catch ME
            warning('EDF processing failed: %s', ME.message);
            continue;
        end

        %% Extract trial times
        [timesStim, actual_trials] = get_trial_times(edf, num_trials);
        if actual_trials == 0
            warning('No valid trials for: %s', subject);
            continue;
        end

        %% Define ROI (Region of Interest)
        % Adjust these coordinates based on your actual ROI
        roi_x = [0, 1024];  % Example X coordinates (adjust based on your screen resolution)
        roi_y = [0, 768];   % Example Y coordinates (adjust based on your screen resolution)
        
        %% Calculate fixation metrics per trial
        for trial = 1:actual_trials
            % Get fixations within trial window
            fix_idx = (fixStarts >= timesStim(trial, 1)) & ...
                      (fixStarts <= timesStim(trial, 2));
            
            % Further filter by ROI
            in_roi = (fixX >= roi_x(1)) & (fixX <= roi_x(2)) & ...
                     (fixY >= roi_y(1)) & (fixY <= roi_y(2));
            
            roi_fix_idx = fix_idx & in_roi;
            
            if sum(roi_fix_idx) > 0
                % Fixation Count (FC)
                all_metrics(s_idx, trial, 1) = sum(roi_fix_idx);
                
                % Average Fixation Duration (AFD)
                all_metrics(s_idx, trial, 2) = mean(fixDurs(roi_fix_idx));
                
                % Total Fixation Duration (TFD)
                all_metrics(s_idx, trial, 3) = sum(fixDurs(roi_fix_idx));
            end
        end
    end

    %% Calculate descriptive statistics (mean and std for each metric)
    fprintf('\n==== CALCULATING DESCRIPTIVE STATISTICS ====\n');
    
    metrics_names = {'Fixation_Count', 'Average_Fixation_Duration', 'Total_Fixation_Duration'};
    metrics_abbr = {'FC', 'AFD', 'TFD'};
    
    % Initialize arrays for storing statistics
    means = zeros(num_trials, 3);
    stds = zeros(num_trials, 3);
    
    for m = 1:3
        for t = 1:num_trials
            data = all_metrics(:, t, m);
            data = data(~isnan(data)); % Remove NaN values
            
            if ~isempty(data)
                means(t, m) = mean(data);
                stds(t, m) = std(data);
            else
                means(t, m) = NaN;
                stds(t, m) = NaN;
            end
        end
    end
    
    % Save descriptive statistics to .mat file
    descriptive_stats = struct();
    for m = 1:3
        descriptive_stats.(metrics_abbr{m}).mean = means(:, m);
        descriptive_stats.(metrics_abbr{m}).std = stds(:, m);
    end
    descriptive_stats.trials = 1:num_trials;
    
    save(fullfile(output_folder, 'descriptive_stats.mat'), 'descriptive_stats');
    fprintf('Descriptive statistics saved to: %s\n', fullfile(output_folder, 'descriptive_stats.mat'));

    %% Calculate correlations with behavioral measures
    fprintf('\n==== CALCULATING CORRELATIONS ====\n');
    
    % Initialize correlation arrays
    correlation_results = struct();
    
    behavioral_measures = {'correctness', 'confidence', 'RT'};
    behavioral_data = {trial_correctness, trial_conf_values, trial_RT_values};
    
    for m = 1:3 % For each fixation metric
        metric_data = all_metrics(:, :, m);
        
        for b = 1:3 % For each behavioral measure
            behav_data = behavioral_data{b};
            
            % Initialize arrays for trial-wise correlations
            corr_coeffs = zeros(num_trials, 1);
            p_values = zeros(num_trials, 1);
            
            % Calculate correlation for each trial
            for t = 1:num_trials
                metric_trial = metric_data(:, t);
                behav_trial = behav_data(:, t);
                
                % Remove NaN values
                valid_idx = ~isnan(metric_trial) & ~isnan(behav_trial);
                
                if sum(valid_idx) >= 3 % Need at least 3 points for correlation
                    [corr_coeffs(t), p_values(t)] = corr(metric_trial(valid_idx), behav_trial(valid_idx));
                else
                    corr_coeffs(t) = NaN;
                    p_values(t) = NaN;
                end
            end
            
            % Calculate overall correlation (across all trials)
            metric_flat = metric_data(:);
            behav_flat = behav_data(:);
            
            % Remove NaN values
            valid_idx = ~isnan(metric_flat) & ~isnan(behav_flat);
            
            if sum(valid_idx) >= 3
                [overall_corr, overall_p] = corr(metric_flat(valid_idx), behav_flat(valid_idx));
            else
                overall_corr = NaN;
                overall_p = NaN;
            end
            
            % Store results
            correlation_results.(metrics_abbr{m}).(behavioral_measures{b}).trial_corr = corr_coeffs;
            correlation_results.(metrics_abbr{m}).(behavioral_measures{b}).trial_p = p_values;
            correlation_results.(metrics_abbr{m}).(behavioral_measures{b}).overall_corr = overall_corr;
            correlation_results.(metrics_abbr{m}).(behavioral_measures{b}).overall_p = overall_p;
        end
    end
    
    % Save correlation results to .mat file
    save(fullfile(output_folder, 'correlation_results.mat'), 'correlation_results');
    fprintf('Correlation results saved to: %s\n', fullfile(output_folder, 'correlation_results.mat'));

    %% Display summary of results
    fprintf('\n==== RESULTS SUMMARY ====\n');
    
    % Display descriptive statistics
    fprintf('\nDESCRIPTIVE STATISTICS:\n');
    fprintf('Trial\tFC Mean\tFC Std\tAFD Mean\tAFD Std\tTFD Mean\tTFD Std\n');
    for t = 1:num_trials
        fprintf('%d\t%.2f\t%.2f\t%.2f\t%.2f\t%.2f\t%.2f\n', t, ...
                means(t, 1), stds(t, 1), means(t, 2), stds(t, 2), means(t, 3), stds(t, 3));
    end
    
    % Display significant correlations
    fprintf('\nSIGNIFICANT CORRELATIONS (p < 0.05):\n');
    for m = 1:3
        for b = 1:3
            metric = metrics_abbr{m};
            measure = behavioral_measures{b};
            
            % Check trial-wise correlations
            for t = 1:num_trials
                p_val = correlation_results.(metric).(measure).trial_p(t);
                if ~isnan(p_val) && p_val < 0.05
                    corr_val = correlation_results.(metric).(measure).trial_corr(t);
                    fprintf('Trial %d: %s vs %s: r = %.3f, p = %.4f\n', ...
                            t, metric, measure, corr_val, p_val);
                end
            end
            
            % Check overall correlation
            p_val = correlation_results.(metric).(measure).overall_p;
            if ~isnan(p_val) && p_val < 0.05
                corr_val = correlation_results.(metric).(measure).overall_corr;
                fprintf('Overall: %s vs %s: r = %.3f, p = %.4f\n', ...
                        metric, measure, corr_val, p_val);
            end
        end
    end

    fprintf('\n==== PROCESSING COMPLETE ====\n');
    fprintf('All results saved to: %s\n', output_folder);
    
    %% Helper Functions
    function [timesStim, actual_trials] = get_trial_times(edf, num_trial)
        % Extract trial start/end times from EDF messages
        all_messages = edf.Events.Messages.info;
        all_times = edf.Events.Messages.time;
        
        % Find start markers
        start_indices = find(contains(all_messages, 'TRIAL_START') | ...
                        contains(all_messages, 'StartFixation') | ...
                        contains(all_messages, 'STIMULUS_ON'));
        
        % Find end markers
        end_indices = find(contains(all_messages, 'TRIAL_END') | ...
                      contains(all_messages, 'EndAnswer') | ...
                      contains(all_messages, 'STIMULUS_OFF'));
        
        % Handle marker count mismatch
        if numel(start_indices) ~= numel(end_indices) || isempty(start_indices)
            actual_trials = 0;
            timesStim = [];
            return;
        end
        
        actual_trials = min(num_trial, numel(start_indices));
        timesStim = [all_times(start_indices(1:actual_trials));...
                     all_times(end_indices(1:actual_trials))].';
    end
end