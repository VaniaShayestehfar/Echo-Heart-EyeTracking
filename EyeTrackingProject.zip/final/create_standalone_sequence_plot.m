function create_standalone_sequence_plot()
    % Clear workspace and close figures
    clear all; 
    close all; 
    clc;
    
    % Example data - you can replace this with your actual data
    aoi_sequence = [1, 2, 3, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5, 6, 1, 2, 3, 4, 5];
    aoi_labels = {'Option1', 'Option2', 'Option3', 'Option4', 'Option5', 'Question'};
    aoi_colors = [1 0 0;      % Red - Option1
                  0 1 0;      % Green - Option2
                  0 0 1;      % Blue - Option3
                  1 1 0;      % Yellow - Option4
                  1 0 1;      % Magenta - Option5
                  0 1 1];     % Cyan - Question
    
    subject = 'Kasra';
    trial = 1;
    output_folder = 'E:\test_output';
    
    % Create output folder if needed
    if ~exist(output_folder, 'dir')
        mkdir(output_folder);
    end
    
    % Create a figure for the sequence plot
    fig = figure('Position', [100, 100, 1200, 300], 'Color', 'white');
    
    % Filter out zeros (fixations outside AOIs)
    valid_sequence = aoi_sequence(aoi_sequence > 0);
    
    if isempty(valid_sequence)
        fprintf('No AOI visits for %s trial %d. Skipping sequence plot.\n', subject, trial);
        close(fig);
        return;
    end
    
    % Create colored horizontal bars for the sequence
    for i = 1:length(valid_sequence)
        aoi_idx = valid_sequence(i);
        rectangle('Position', [i-0.5, 0, 1, 1], 'FaceColor', aoi_colors(aoi_idx, :), 'EdgeColor', 'none');
        hold on;
    end
    
    % Customize the plot to match the OIP.jpg style
    set(gca, 'YTick', [], 'FontSize', 12, 'LineWidth', 1.5, 'Box', 'on');
    xlabel('Fixation Number', 'FontSize', 14, 'FontWeight', 'bold');
    ylim([0, 1]);
    xlim([0.5, length(valid_sequence)+0.5]);
    title(sprintf('AOI Sequence: %s - Trial %d', subject, trial), ...
          'FontSize', 16, 'FontWeight', 'bold');
    
    % Add legend
    legend(aoi_labels, 'Location', 'eastoutside');
    
    % Save the plot
    saveas(fig, fullfile(output_folder, sprintf('Trial_%d_AOI_Sequence.png', trial)));
    
    fprintf('Plot saved to: %s\n', fullfile(output_folder, sprintf('Trial_%d_AOI_Sequence.png', trial)));
end