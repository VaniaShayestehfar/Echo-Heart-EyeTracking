function visualizeAOISequence(subjectID, trialID)
    % VISUALIZEAOISEQUENCE Plot AOI sequence for a specific subject and trial
    %   subjectID: Index of the subject (1-26)
    %   trialID: Index of the trial (1-8)
    subjectID = 7;  % Change to desired subject
trialID = 4;    % Change to desired trial

    % Load the saved AOI sequences
    load('all_sequences.mat', 'allSequences', 'subjects');
    
    % Check if the requested subject and trial exist
    if subjectID > size(allSequences, 1) || subjectID < 1
        error('Subject ID out of range. Available subjects: 1 to %d', size(allSequences, 1));
    end
    
    if trialID > size(allSequences, 2) || trialID < 1
        error('Trial ID out of range. Available trials: 1 to %d', size(allSequences, 2));
    end
    
    sequence = allSequences{subjectID, trialID};
    
    if isempty(sequence)
        error('No data for subject %d (%s), trial %d', subjectID, subjects{subjectID}, trialID);
    end
    
    % Create color map for different AOI types
    colors = containers.Map();
    colors('Question') = [0.2, 0.6, 1.0];     % Blue for question boxes
    colors('Picture') = [0.8, 0.4, 0.1];      % Orange for picture boxes
    colors('CorrectAnswer') = [0.1, 0.8, 0.2]; % Green for correct answers
    colors('WrongAnswer') = [1.0, 0.2, 0.2];  % Red for wrong answers
    colors('GoodBox') = [0.4, 0.8, 0.4];      % Light green for good boxes
    colors('BadBox') = [1.0, 0.6, 0.6];       % Light red for bad boxes
    colors('None') = [0.8, 0.8, 0.8];         % Gray for no AOI
    
    % Create plot
    figure('Position', [100, 100, 1200, 500], 'Color', 'w');
    hold on;
    
    % Pre-assign y-levels for all AOI types that appear in this sequence
    yLevels = containers.Map();
    aoiList = {};
    yPos = 1;
    
    % First pass: Identify all unique AOIs in this sequence
    for i = 1:length(sequence)
        aoi = sequence(i).AOI;
        if ~yLevels.isKey(aoi)
            yLevels(aoi) = yPos;
            aoiList{end+1} = aoi;
            yPos = yPos + 1;
        end
    end
    
    % Second pass: Plot fixation durations and transitions
    for i = 1:length(sequence)
        aoi = sequence(i).AOI;
        yVal = yLevels(aoi);
        
        % Plot fixation duration
        plot([sequence(i).Start, sequence(i).End], [yVal, yVal], ...
            'Color', colors(aoi), 'LineWidth', 20);
        
        % Plot transition to next fixation
        if i < length(sequence)
            nextAOI = sequence(i+1).AOI;
            nextStart = sequence(i+1).Start;
            nextYVal = yLevels(nextAOI);
            
            plot([sequence(i).End, nextStart], [yVal, nextYVal], ...
                'k-', 'LineWidth', 1.5);
        end
    end
    
    % Add AOI labels
    for i = 1:length(aoiList)
        aoi = aoiList{i};
        text(max([sequence.End]) + 1, yLevels(aoi), aoi, ...
            'FontSize', 12, 'FontWeight', 'bold');
    end
    
    % Configure plot
    title(sprintf('AOI Sequence for Subject %d (%s), Trial %d', subjectID, subjects{subjectID}, trialID), ...
        'FontSize', 14, 'FontWeight', 'bold');
    xlabel('Time (seconds)', 'FontSize', 12, 'FontWeight', 'bold');
    ylabel('AOI Type', 'FontSize', 12, 'FontWeight', 'bold');
    set(gca, 'YTick', cell2mat(yLevels.values(aoiList)), ...
        'YTickLabel', aoiList, ...
        'FontSize', 10, ...
        'TickDir', 'out', ...
        'Box', 'off', ...
        'YGrid', 'on', ...
        'GridLineStyle', '--', ...
        'GridAlpha', 0.2, ...
        'XGrid', 'on');
    xlim([min([sequence.Start]) - 1, max([sequence.End]) + 5]);
    
    % Add legend
    legend(aoiList, 'Location', 'northeastoutside');
    
    hold off;
    
    % Save plot
    saveas(gcf, sprintf('AOI_Sequence_Subject%d_Trial%d.png', subjectID, trialID));
end