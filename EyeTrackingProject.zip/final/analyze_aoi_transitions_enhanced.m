function analyze_aoi_transitions_enhanced()
    % Clear workspace and close figures
    clear all; 
    close all; 
    clc;
    
    %% Parameters
    num_trials = 8;
    subjects = {'Kasra', 'Javad', 'Milad', 'MMD', 'MohAli', 'Mohsen', 'Yashar', 'Arsham',...
               'Aliyz', 'Amin', 'Hasti', 'Hosein', 'Karimi', 'Mahdii', 'Mahy', 'Meli',...
               'MhMhd', 'Mitra', 'Mobina', 'Mohamad', 'Most', 'Moti', 'Saba', 'Sheri',...
               'SinFa', 'Telma'};
    
    % File paths
    edfDir = 'E:\EYE_TRACKING_PROJECT\matlab';
    output_folder = 'E:\EYE_TRACKING_PROJECT\matlab\AOI_Transition_Analysis_Enhanced\';
    
    % Create output folder if needed
    if ~exist(output_folder, 'dir')
        mkdir(output_folder);
    end

    %% Define AOIs (Areas of Interest)
    % Using a structure array for better organization
    aois = struct();
    
    % Define AOI coordinates and labels based on your screenshot
    % Format: [x1, y1, x2, y2], 'Label'
    aois(1).coords = [100, 100, 300, 200];
    aois(1).label = 'Option1';
    
    aois(2).coords = [400, 100, 600, 200];
    aois(2).label = 'Option2';
    
    aois(3).coords = [700, 100, 900, 200];
    aois(3).label = 'Option3';
    
    aois(4).coords = [100, 300, 300, 400];
    aois(4).label = 'Option4';
    
    aois(5).coords = [400, 300, 600, 400];
    aois(5).label = 'Option5';
    
    aois(6).coords = [700, 300, 900, 400];
    aois(6).label = 'Question';
    
    num_aois = length(aois);
    
    % Create rainbow colors for AOIs
    rainbow_colors = hsv(num_aois);
    for i = 1:num_aois
        aois(i).color = rainbow_colors(i, :);
    end
    
    %% Initialize data storage
    % We'll store sequences and dwell times for each subject and trial
    all_aoi_sequences = cell(numel(subjects), num_trials);
    all_dwell_times = cell(numel(subjects), num_trials);
    all_fixation_times = cell(numel(subjects), num_trials);
    
    %% Process each subject
    for s_idx = 1:numel(subjects)
        subject = subjects{s_idx};
        fprintf('\n==== PROCESSING SUBJECT: %s ====\n', subject);
        
        % Load EDF data
        edf_file = fullfile(edfDir, [subject '.edf']);
        if ~exist(edf_file, 'file')
            warning('EDF file not found: %s', edf_file);
            continue;
        end
        
        try
            edf = Edf2Mat(edf_file);
            fixations = edf.Events.Efix;
            fixStarts = [fixations.start];
            fixDurs = [fixations.duration];
            fixX = [fixations.posX];
            fixY = [fixations.posY];
        catch ME
            warning('EDF processing failed: %s', ME.message);
            continue;
        end

        %% Extract trial times
        [timesStim, actual_trials] = get_trial_times(edf, num_trials);
        if actual_trials == 0
            warning('No valid trials for: %s', subject);
            continue;
        end

        %% Process each trial
        for trial = 1:actual_trials
            fprintf('  Processing trial %d...\n', trial);
            
            % Get fixations within trial window
            fix_idx = (fixStarts >= timesStim(trial, 1)) & ...
                      (fixStarts <= timesStim(trial, 2));
            
            trial_fix_x = fixX(fix_idx);
            trial_fix_y = fixY(fix_idx);
            trial_fix_durs = fixDurs(fix_idx);
            trial_fix_starts = fixStarts(fix_idx);
            
            % Map fixations to AOIs
            aoi_sequence = [];
            dwell_times = zeros(1, num_aois);
            fixation_times = cell(1, num_aois);
            
            for f = 1:length(trial_fix_x)
                current_aoi = 0; % 0 means outside all AOIs
                
                % Check which AOI this fixation belongs to
                for a = 1:num_aois
                    aoi_coords = aois(a).coords;
                    if trial_fix_x(f) >= aoi_coords(1) && trial_fix_x(f) <= aoi_coords(3) && ...
                       trial_fix_y(f) >= aoi_coords(2) && trial_fix_y(f) <= aoi_coords(4)
                        current_aoi = a;
                        dwell_times(a) = dwell_times(a) + trial_fix_durs(f);
                        
                        % Record fixation time
                        if isempty(fixation_times{a})
                            fixation_times{a} = trial_fix_starts(f);
                        else
                            fixation_times{a} = [fixation_times{a}, trial_fix_starts(f)];
                        end
                        
                        break;
                    end
                end
                
                aoi_sequence = [aoi_sequence, current_aoi];
            end
            
            % Store results
            all_aoi_sequences{s_idx, trial} = aoi_sequence;
            all_dwell_times{s_idx, trial} = dwell_times;
            all_fixation_times{s_idx, trial} = fixation_times;
            
            %% Create sequence plot for this subject and trial
            create_sequence_plot_enhanced(aoi_sequence, dwell_times, aois, subject, trial, output_folder);
            
            %% Create timecourse plot for this subject and trial
            create_timecourse_plot_enhanced(fixation_times, dwell_times, aois, subject, trial, timesStim(trial, :), output_folder);
            
            %% Create dwell time plot for this subject and trial
            create_dwell_time_plot_enhanced(dwell_times, aois, subject, trial, output_folder);
        end
    end
    
    %% Create summary statistics across subjects
    fprintf('\n==== CREATING SUMMARY STATISTICS ====\n');
    
    % Initialize summary arrays
    summary_dwell_times = zeros(num_aois, num_trials);
    valid_counts = zeros(1, num_trials);
    
    for trial = 1:num_trials
        for s_idx = 1:numel(subjects)
            if ~isempty(all_dwell_times{s_idx, trial})
                summary_dwell_times(:, trial) = summary_dwell_times(:, trial) + all_dwell_times{s_idx, trial}';
                valid_counts(trial) = valid_counts(trial) + 1;
            end
        end
        
        % Average across subjects
        if valid_counts(trial) > 0
            summary_dwell_times(:, trial) = summary_dwell_times(:, trial) / valid_counts(trial);
        end
    end
    
    %% Create summary plots for each trial
    for trial = 1:num_trials
        if valid_counts(trial) > 0
            % Create a bar plot of average dwell times
            fig = figure('Position', [100, 100, 1000, 600]);
            
            bar_data = summary_dwell_times(:, trial)';
            
            % Create colored bars
            for a = 1:num_aois
                bar_handles(a) = bar(a, bar_data(a));
                bar_handles(a).FaceColor = aois(a).color;
                hold on;
            end
            
            % Customize plot
            set(gca, 'XTick', 1:num_aois, 'XTickLabel', {aois.label}, ...
                     'FontSize', 12, 'LineWidth', 1.5);
            ylabel('Dwell Time (ms)', 'FontSize', 14, 'FontWeight', 'bold');
            title(sprintf('Average Dwell Times - Trial %d', trial), ...
                  'FontSize', 16, 'FontWeight', 'bold');
            grid on;
            
            % Add value labels on bars
            for a = 1:num_aois
                text(a, bar_data(a), sprintf('%.0f ms', bar_data(a)), ...
                     'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom', ...
                     'FontSize', 10, 'FontWeight', 'bold');
            end
            
            % Save plot
            saveas(fig, fullfile(output_folder, sprintf('Trial_%d_Avg_Dwell_Times.png', trial)));
            close(fig);
        end
    end
    
    %% Save results
    save(fullfile(output_folder, 'aoi_analysis_data.mat'), ...
         'all_aoi_sequences', 'all_dwell_times', 'all_fixation_times', ...
         'summary_dwell_times', 'aois', 'subjects');
    
    fprintf('\n==== ANALYSIS COMPLETE ====\n');
    fprintf('All results saved to: %s\n', output_folder);
    
    %% Helper Functions
    function [timesStim, actual_trials] = get_trial_times(edf, num_trial)
        % Extract trial start/end times from EDF messages
        all_messages = edf.Events.Messages.info;
        all_times = edf.Events.Messages.time;
        
        % Find start markers
        start_indices = find(contains(all_messages, 'TRIAL_START') | ...
                        contains(all_messages, 'StartFixation') | ...
                        contains(all_messages, 'STIMULUS_ON'));
        
        % Find end markers
        end_indices = find(contains(all_messages, 'TRIAL_END') | ...
                      contains(all_messages, 'EndAnswer') | ...
                      contains(all_messages, 'STIMULUS_OFF'));
        
        % Handle marker count mismatch
        if numel(start_indices) ~= numel(end_indices) || isempty(start_indices)
            actual_trials = 0;
            timesStim = [];
            return;
        end
        
        actual_trials = min(num_trial, numel(start_indices));
        timesStim = [all_times(start_indices(1:actual_trials));...
                     all_times(end_indices(1:actual_trials))].';
    end
    
    function create_sequence_plot_enhanced(aoi_sequence, dwell_times, aois, subject, trial, output_folder)
        % Create a figure for the sequence plot
        fig = figure('Position', [100, 100, 1200, 300]);
        
        % Filter out zeros (fixations outside AOIs)
        valid_sequence = aoi_sequence(aoi_sequence > 0);
        
        if isempty(valid_sequence)
            fprintf('No AOI visits for %s trial %d. Skipping sequence plot.\n', subject, trial);
            close(fig);
            return;
        end
        
        % Create colored horizontal bars for the sequence
        for i = 1:length(valid_sequence)
            aoi_idx = valid_sequence(i);
            rectangle('Position', [i-0.5, 0, 1, 1], 'FaceColor', aois(aoi_idx).color, 'EdgeColor', 'none');
            hold on;
        end
        
        % Customize the plot
        set(gca, 'YTick', [], 'FontSize', 12, 'LineWidth', 1.5, 'Box', 'on');
        xlabel('Fixation Number', 'FontSize', 14, 'FontWeight', 'bold');
        ylim([0, 1]);
        xlim([0.5, length(valid_sequence)+0.5]);
        title(sprintf('AOI Sequence: %s - Trial %d', subject, trial), ...
              'FontSize', 16, 'FontWeight', 'bold');
        
        % Add legend
        legend_entries = cell(1, num_aois);
        for a = 1:num_aois
            legend_entries{a} = aois(a).label;
        end
        legend(legend_entries, 'Location', 'eastoutside');
        
        % Save the plot
        subject_folder = fullfile(output_folder, subject);
        if ~exist(subject_folder, 'dir')
            mkdir(subject_folder);
        end
        
        saveas(fig, fullfile(subject_folder, sprintf('Trial_%d_AOI_Sequence.png', trial)));
        close(fig);
    end
    
    function create_timecourse_plot_enhanced(fixation_times, dwell_times, aois, subject, trial, trial_times, output_folder)
        % Create a figure for the timecourse plot
        fig = figure('Position', [100, 100, 1200, 600]);
        
        % Define time intervals (5-second intervals as in the screenshot)
        interval_duration = 5000; % 5 seconds in milliseconds
        trial_duration = trial_times(2) - trial_times(1);
        num_intervals = ceil(trial_duration / interval_duration);
        
        % Initialize dwell time matrix for intervals
        interval_dwell = zeros(num_aois, num_intervals);
        
        % Calculate dwell times for each interval
        for a = 1:num_aois
            if ~isempty(fixation_times{a})
                for i = 1:num_intervals
                    interval_start = trial_times(1) + (i-1)*interval_duration;
                    interval_end = interval_start + interval_duration;
                    
                    % Find fixations in this interval
                    in_interval = fixation_times{a} >= interval_start & fixation_times{a} < interval_end;
                    
                    % Sum dwell times for this interval (approximate)
                    interval_dwell(a, i) = sum(in_interval) * mean(fixation_times{a}(in_interval));
                end
            end
        end
        
        % Plot the timecourse with rainbow colors
        for a = 1:num_aois
            plot(1:num_intervals, interval_dwell(a, :), 'Color', aois(a).color, 'LineWidth', 3, 'Marker', 'o', 'MarkerSize', 8, 'MarkerFaceColor', aois(a).color);
            hold on;
        end
        
        % Customize the plot
        set(gca, 'FontSize', 12, 'LineWidth', 1.5);
        xlabel('Time Interval (5s)', 'FontSize', 14, 'FontWeight', 'bold');
        ylabel('Dwell Time (ms)', 'FontSize', 14, 'FontWeight', 'bold');
        title(sprintf('Dwell Time Timecourse: %s - Trial %d', subject, trial), ...
              'FontSize', 16, 'FontWeight', 'bold');
        grid on;
        
        % Add legend
        legend_entries = cell(1, num_aois);
        for a = 1:num_aois
            legend_entries{a} = aois(a).label;
        end
        legend(legend_entries, 'Location', 'eastoutside');
        
        % Save the plot
        subject_folder = fullfile(output_folder, subject);
        if ~exist(subject_folder, 'dir')
            mkdir(subject_folder);
        end
        
        saveas(fig, fullfile(subject_folder, sprintf('Trial_%d_Timecourse.png', trial)));
        close(fig);
    end
    
    function create_dwell_time_plot_enhanced(dwell_times, aois, subject, trial, output_folder)
        % Create a figure for the dwell time plot
        fig = figure('Position', [100, 100, 1000, 600]);
        
        % Create a bar chart of dwell times
        bar_handles = bar(dwell_times);
        
        % Customize the bar colors
        for a = 1:num_aois
            bar_handles.FaceColor = 'flat';
            bar_handles.CData(a, :) = aois(a).color;
        end
        
        % Customize the plot
        set(gca, 'XTick', 1:num_aois, 'XTickLabel', {aois.label}, ...
                 'FontSize', 12, 'LineWidth', 1.5);
        ylabel('Dwell Time (ms)', 'FontSize', 14, 'FontWeight', 'bold');
        title(sprintf('Dwell Time Distribution: %s - Trial %d', subject, trial), ...
              'FontSize', 16, 'FontWeight', 'bold');
        grid on;
        
        % Add value labels on bars
        for a = 1:num_aois
            text(a, dwell_times(a), sprintf('%d ms', dwell_times(a)), ...
                 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom', ...
                 'FontSize', 10, 'FontWeight', 'bold');
        end
        
        % Save the plot
        subject_folder = fullfile(output_folder, subject);
        if ~exist(subject_folder, 'dir')
            mkdir(subject_folder);
        end
        
        saveas(fig, fullfile(subject_folder, sprintf('Trial_%d_Dwell_Time.png', trial)));
        close(fig);
    end
end