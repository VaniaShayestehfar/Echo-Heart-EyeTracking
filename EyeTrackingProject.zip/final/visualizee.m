function visualizee()
    % Clear workspace and close figures
    clear all; 
    close all; 
    clc;

    %% Parameters
    num_trials = 8;  % Total number of trials
    correct_ans = [1, 3, 1, 4, 2, 2, 5, 2];  % Correct answers for each trial
    subjects = {'Kasra', 'Javad', 'Milad', 'MMD', 'MohAli', 'Mohsen', 'Yashar', 'Arsham','Aliyz','Amin','Hasti','Hosein','Karimi','Mahdii','Mahy','Meli','MhMhd','Mitra','Mobina','Mohamad','Most','Moti','Saba','Sheri','SinFa','Telma'};  % List of subjects
    
    % File paths
    edfDir = 'E:\EYE_TRACKING_PROJECT\matlab';            % EDF files location
    img_address = 'E:\EYE_TRACKING_PROJECT\matlab';       % Stimulus images location
    Data_path = 'E:\EYE_TRACKING_PROJECT\matlab\';        % Behavioral data location
    output_folder = 'E:\EYE_TRACKING_PROJECT\matlab\Duration_Accuracy_Plots\'; % Output folder
    
    % Create output folder if needed
    if ~exist(output_folder, 'dir')
        mkdir(output_folder);
    end

    %% Load behavioral data
    fprintf('\n==== LOADING BEHAVIORAL DATA ====\n');
    subject_trial_correctness = containers.Map();  % Store per-trial correctness
    
    files = dir(fullfile(Data_path, '*.mat'));
    for i = 1:numel(files)
        file_path = fullfile(Data_path, files(i).name);
        try
            data_struct = load(file_path);
            
            % Extract subject name
            if isfield(data_struct, 'subName')
                subject_name = data_struct.subName;
            else
                [~, subject_name] = fileparts(files(i).name);
            end
            
            % Calculate per-trial correctness
            if isfield(data_struct, 'resp')
                resp = data_struct.resp;
                trial_correct = nan(1, num_trials);
                
                for j = 1:min(num_trials, numel(resp))
                    if j <= numel(resp) && ~isempty(resp{j})
                        if resp{j}(1) == correct_ans(j)
                            trial_correct(j) = 1;
                        elseif numel(resp{j}) >= 2 && resp{j}(2) == correct_ans(j)
                            trial_correct(j) = 0.7;
                        elseif numel(resp{j}) >= 3 && resp{j}(3) == correct_ans(j)
                            trial_correct(j) = 0.3;
                        else
                            trial_correct(j) = 0;
                        end
                    else
                        trial_correct(j) = 0;
                    end
                end
                subject_trial_correctness(subject_name) = trial_correct;
            end
        catch ME
            warning('Error processing %s: %s', file_path, ME.message);
        end
    end

    %% Process each subject
    for s_idx = 1:numel(subjects)
        subject = subjects{s_idx};  % Current subject
        fprintf('\n==== PROCESSING SUBJECT: %s ====\n', subject);
        
        % Initialize data storage
        trial_durations = zeros(1, num_trials);
        trial_accuracies = zeros(1, num_trials);
        
        % Get accuracy data
        subject_found = false;
        all_keys = subject_trial_correctness.keys;
        for k = 1:numel(all_keys)
            if strcmpi(all_keys{k}, subject)
                trial_accuracies = subject_trial_correctness(all_keys{k});
                subject_found = true;
                break;
            end
        end
        
        if ~subject_found
            warning('No accuracy data for: %s', subject);
            continue;
        end

        % Load EDF data
        edf_file = fullfile(edfDir, [subject '.edf']);
        if ~exist(edf_file, 'file')
            warning('EDF file not found: %s', edf_file);
            continue;
        end
        
        try
            edf = Edf2Mat(edf_file);
            fixations = edf.Events.Efix;
            fixStarts = [fixations.start];
            fixDurs = [fixations.duration];
        catch ME
            warning('EDF processing failed: %s', ME.message);
            continue;
        end

        %% Extract trial times
        [timesStim, actual_trials] = get_trial_times(edf, num_trials);
        if actual_trials == 0
            warning('No valid trials for: %s', subject);
            continue;
        end

        %% Calculate fixation durations per trial
        for trial = 1:actual_trials
            % Get fixations within trial window
            fix_idx = (fixStarts >= timesStim(trial, 1)) & ...
                      (fixStarts <= timesStim(trial, 2));
            trial_durations(trial) = sum(fixDurs(fix_idx));
        end

        %% Generate and save plot
        create_duration_accuracy_plot(trial_durations, trial_accuracies, subject, output_folder);
    end
    
    fprintf('\n==== PROCESSING COMPLETE ====\n');
    
    %% Helper Functions
    function [timesStim, actual_trials] = get_trial_times(edf, num_trial)
        % Extract trial start/end times from EDF messages
        all_messages = edf.Events.Messages.info;
        all_times = edf.Events.Messages.time;
        
        % Find start markers
        start_indices = find(contains(all_messages, 'TRIAL_START') | ...
                        contains(all_messages, 'StartFixation') | ...
                        contains(all_messages, 'STIMULUS_ON'));
        
        % Find end markers
        end_indices = find(contains(all_messages, 'TRIAL_END') | ...
                      contains(all_messages, 'EndAnswer') | ...
                      contains(all_messages, 'STIMULUS_OFF'));
        
        % Handle marker count mismatch
        if numel(start_indices) ~= numel(end_indices) || isempty(start_indices)
            actual_trials = 0;
            timesStim = [];
            return;
        end
        
        actual_trials = min(num_trial, numel(start_indices));
        timesStim = [all_times(start_indices(1:actual_trials));...
                     all_times(end_indices(1:actual_trials))].';
    end

    function create_duration_accuracy_plot(durations, accuracies, subject, output_folder)
        % Create per-trial duration vs accuracy plot
        fig = figure('Position', [100, 100, 1200, 800], 'Visible', 'off');
        
        % Plot each trial
        hold on;
        for trial = 1:num_trials
            if isnan(accuracies(trial)) || durations(trial) == 0
                continue;
            end
            
            % Determine marker color based on accuracy
            if accuracies(trial) == 1
                color = [0, 0.7, 0];  % Green for correct
            elseif accuracies(trial) >= 0.7
                color = [0.3, 0.8, 0.3];  % Light green
            elseif accuracies(trial) >= 0.3
                color = [1, 0.6, 0];  % Orange
            else
                color = [1, 0, 0];  % Red for incorrect
            end
            
            % Plot marker with subject name
            scatter(trial, durations(trial), 300, 'filled', ...
                'MarkerFaceColor', color, ...
                'MarkerEdgeColor', 'k', ...
                'LineWidth', 1.5);
            text(trial, durations(trial), subject, ...
                'HorizontalAlignment', 'center', ...
                'VerticalAlignment', 'middle', ...
                'FontSize', 10, ...
                'FontWeight', 'bold', ...
                'Color', 'white');
        end
        
        % Configure plot
        xlim([0.5, num_trials + 0.5]);
        set(gca, 'XTick', 1:num_trials, ...
                 'XTickLabel', arrayfun(@(x) sprintf('Trial %d', x), 1:num_trials, 'UniformOutput', false), ...
                 'FontSize', 12);
        ylabel('Fixation Duration (ms)', 'FontSize', 14, 'FontWeight', 'bold');
        title(sprintf('Fixation Duration vs. Accuracy: %s', subject), 'FontSize', 16, 'FontWeight', 'bold');
        grid on;
        
        % Add accuracy color legend
        legend_entries = {
            'Correct (1.0)', 
            'Partially Correct (0.7)', 
            'Partially Correct (0.3)', 
            'Incorrect (0.0)'
        };
        legend_colors = [
            0 0.7 0; 
            0.3 0.8 0.3; 
            1 0.6 0; 
            1 0 0
        ];
        h = zeros(4, 1);
        for i = 1:4
            h(i) = plot(NaN, NaN, 'o', ...
                'MarkerSize', 10, ...
                'MarkerFaceColor', legend_colors(i,:), ...
                'MarkerEdgeColor', 'k');
        end
        legend(h, legend_entries, 'Location', 'northeastoutside', 'FontSize', 10);
        
        % Save plot
        saveas(fig, fullfile(output_folder, [subject '_Duration_Accuracy.png']));
        close(fig);
        fprintf('Saved plot for: %s\n', subject);
    end
    function visualize_fixations_duration_vs_accuracy()
    % Clear workspace and close figures
    clear all; 
    close all; 
    clc;

    %% Parameters
    num_trials = 8;  % Total number of trials
    correct_ans = [1, 3, 1, 4, 2, 2, 5, 2];  % Correct answers for each trial
    subjects = {'Kasra', 'Javad', 'Milad', 'MMD', 'MohAli', 'Mohsen', 'Yashar', 'Arsham','Aliyz','Amin','Hasti','Hosein','Karimi','Mahdii','Mahy','Meli','MhMhd','Mitra','Mobina','Mohamad','Most','Moti','Saba','Sheri','SinFa','Telma'};  % List of subjects
    
    % File paths
    edfDir = 'E:\EYE_TRACKING_PROJECT\matlab';            % EDF files location
    Data_path = 'E:\EYE_TRACKING_PROJECT\matlab\';        % Behavioral data location
    output_folder = 'E:\EYE_TRACKING_PROJECT\matlab\Duration_Accuracy_Plots\'; % Output folder
    
    % Create output folder if needed
    if ~exist(output_folder, 'dir')
        mkdir(output_folder);
    end

    %% Initialize data storage
    % We'll store data in a 3D matrix: subjects x trials x [duration, accuracy]
    all_data = nan(numel(subjects), num_trials, 2);
    
    %% Load behavioral data
    fprintf('\n==== LOADING BEHAVIORAL DATA ====\n');
    subject_trial_correctness = containers.Map();  % Store per-trial correctness
    
    files = dir(fullfile(Data_path, '*.mat'));
    for i = 1:numel(files)
        file_path = fullfile(Data_path, files(i).name);
        try
            data_struct = load(file_path);
            
            % Extract subject name
            if isfield(data_struct, 'subName')
                subject_name = data_struct.subName;
            else
                [~, subject_name] = fileparts(files(i).name);
            end
            
            % Calculate per-trial correctness
            if isfield(data_struct, 'resp')
                resp = data_struct.resp;
                trial_correct = nan(1, num_trials);
                
                for j = 1:min(num_trials, numel(resp))
                    if j <= numel(resp) && ~isempty(resp{j})
                        if resp{j}(1) == correct_ans(j)
                            trial_correct(j) = 1;
                        elseif numel(resp{j}) >= 2 && resp{j}(2) == correct_ans(j)
                            trial_correct(j) = 0.7;
                        elseif numel(resp{j}) >= 3 && resp{j}(3) == correct_ans(j)
                            trial_correct(j) = 0.3;
                        else
                            trial_correct(j) = 0;
                        end
                    else
                        trial_correct(j) = 0;
                    end
                end
                subject_trial_correctness(subject_name) = trial_correct;
            end
        catch ME
            warning('Error processing %s: %s', file_path, ME.message);
        end
    end

    %% Process each subject
    for s_idx = 1:numel(subjects)
        subject = subjects{s_idx};  % Current subject
        fprintf('\n==== PROCESSING SUBJECT: %s ====\n', subject);
        
        % Get accuracy data
        subject_found = false;
        all_keys = subject_trial_correctness.keys;
        for k = 1:numel(all_keys)
            if strcmpi(all_keys{k}, subject)
                trial_accuracies = subject_trial_correctness(all_keys{k});
                subject_found = true;
                break;
            end
        end
        
        if ~subject_found
            warning('No accuracy data for: %s', subject);
            continue;
        end

        % Load EDF data
        edf_file = fullfile(edfDir, [subject '.edf']);
        if ~exist(edf_file, 'file')
            warning('EDF file not found: %s', edf_file);
            continue;
        end
        
        try
            edf = Edf2Mat(edf_file);
            fixations = edf.Events.Efix;
            fixStarts = [fixations.start];
            fixDurs = [fixations.duration];
        catch ME
            warning('EDF processing failed: %s', ME.message);
            continue;
        end

        %% Extract trial times
        [timesStim, actual_trials] = get_trial_times(edf, num_trials);
        if actual_trials == 0
            warning('No valid trials for: %s', subject);
            continue;
        end

        %% Calculate fixation durations per trial
        for trial = 1:actual_trials
            % Get fixations within trial window
            fix_idx = (fixStarts >= timesStim(trial, 1)) & ...
                      (fixStarts <= timesStim(trial, 2));
            all_data(s_idx, trial, 1) = sum(fixDurs(fix_idx));  % Duration
            all_data(s_idx, trial, 2) = trial_accuracies(trial);  % Accuracy
        end
    end

    %% Generate and save plots per trial
    fprintf('\n==== GENERATING PER-TRIAL PLOTS ====\n');
    
    % Define distinct colors for subjects
    subject_colors = lines(numel(subjects));
    
    for trial = 1:num_trials
        fprintf('Creating plot for Trial %d\n', trial);
        
        % Prepare figure
        fig = figure('Position', [100, 100, 1200, 800]);
        hold on;
        grid on;
        
        % Set labels and title
        xlabel('Accuracy', 'FontSize', 14, 'FontWeight', 'bold');
        ylabel('Fixation Duration (ms)', 'FontSize', 14, 'FontWeight', 'bold');
        title(sprintf('Trial %d: Fixation Duration vs. Accuracy', trial), ...
              'FontSize', 16, 'FontWeight', 'bold');
        
        % Set discrete X-axis
        xlim([-0.2, 1.2]);
        set(gca, 'XTick', [0, 0.3, 0.7, 1], ...
                 'XTickLabel', {'0 (Incorrect)', '0.3', '0.7', '1 (Correct)'}, ...
                 'FontSize', 12);
        
        % Plot each subject
        legend_entries = {};
        for s_idx = 1:numel(subjects)
            duration = all_data(s_idx, trial, 1);
            accuracy = all_data(s_idx, trial, 2);
            
            % Skip missing data
            if isnan(duration) || isnan(accuracy)
                continue;
            end
            
            % Add jitter to avoid overlapping points
            jitter = 0.02 * randn();
            x_pos = accuracy + jitter;
            
            % Plot data point
            scatter(x_pos, duration, 120, 'filled', ...
                    'MarkerFaceColor', subject_colors(s_idx, :), ...
                    'MarkerEdgeColor', 'k', ...
                    'LineWidth', 1.5);
            
            % Add subject name
            text(x_pos, duration + 0.01 * max(ylim), subjects{s_idx}, ...
                 'FontSize', 10, ...
                 'FontWeight', 'bold', ...
                 'HorizontalAlignment', 'center', ...
                 'Color', subject_colors(s_idx, :));
            
            % Add to legend
            legend_entries{end+1} = subjects{s_idx};
        end
        
        % Add legend
        if ~isempty(legend_entries)
            legend(legend_entries, 'Location', 'eastoutside', 'FontSize', 10);
        end
        
        % Save plot
        saveas(fig, fullfile(output_folder, sprintf('Trial_%d_Duration_vs_Accuracyy.png', trial)));
        close(fig);
    end
    
    fprintf('\n==== PROCESSING COMPLETE ====\n');
    
    %% Helper Functions
    function [timesStim, actual_trials] = get_trial_times(edf, num_trial)
        % Extract trial start/end times from EDF messages
        all_messages = edf.Events.Messages.info;
        all_times = edf.Events.Messages.time;
        
        % Find start markers
        start_indices = find(contains(all_messages, 'TRIAL_START') | ...
                        contains(all_messages, 'StartFixation') | ...
                        contains(all_messages, 'STIMULUS_ON'));
        
        % Find end markers
        end_indices = find(contains(all_messages, 'TRIAL_END') | ...
                      contains(all_messages, 'EndAnswer') | ...
                      contains(all_messages, 'STIMULUS_OFF'));
        
        % Handle marker count mismatch
        if numel(start_indices) ~= numel(end_indices) || isempty(start_indices)
            actual_trials = 0;
            timesStim = [];
            return;
        end
        
        actual_trials = min(num_trial, numel(start_indices));
        timesStim = [all_times(start_indices(1:actual_trials));...
                     all_times(end_indices(1:actual_trials))].';
    end
end
end