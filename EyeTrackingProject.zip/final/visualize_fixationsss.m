function visualize_fixationsss()
    % Clear workspace and close figures
    clear all; 
    close all; 
    clc;

    %% Parameters
    num_trials = 8;  % Total number of trials
    subjects = {'Kasra', 'Javad', 'Milad', 'MMD', 'MohAli', 'Mohsen', 'Yashar'};  % List of subjects
    trial_colors = lines(8);  % Predefined distinct colors for 8 trials (RGB values)
    
    % Visualization parameters
    min_radius = 25;    % Minimum circle radius (pixels)
    max_radius = 60;    % Maximum circle radius (pixels)
    min_duration = 200; % Minimum fixation duration to display (ms)
    max_duration = 800; % Maximum fixation duration to display (ms)
    circle_alpha = 0.4; % Transparency level for circles (0=transparent, 1=opaque)
    img_alpha = 0.9;    % Transparency level for background image
    
    % File paths
    edfDir = 'E:\EYE_TRACKING_PROJECT\matlab';            % EDF files location
    img_address = 'E:\EYE_TRACKING_PROJECT\matlab';       % Stimulus images location
    base_output_folder = 'E:\EYE_TRACKING_PROJECT\matlab\Fixation_Duration_Confidence\';  % Main output folder
    duration_output_folder = 'E:\EYE_TRACKING_PROJECT\matlab\Duration_Confidence_Plots\'; % Duration plots folder
    Data_path = 'E:\EYE_TRACKING_PROJECT\matlab\';        % Behavioral data location

    % Create output folders
    if ~exist(duration_output_folder, 'dir')
        mkdir(duration_output_folder);
    end

    %% Load behavioral data and extract confidence
    fprintf('\n==== LOADING BEHAVIORAL DATA ====\n');
    files = dir(fullfile(Data_path, '*.mat'));  % Find all MAT files
    numData = numel(files);  % Number of data files found
    subject_confidences = containers.Map();  % Create map to store confidence data
    
    % Process each behavioral data file
    for i = 1:numData
        file_path = fullfile(Data_path, files(i).name);  % Full file path
        fprintf('Loading behavioral data %d: %s\n', i, file_path);
        
        try
            data_struct = load(file_path);  % Load MAT file
            
            % Extract subject name from filename if 'subName' field doesn't exist
            if isfield(data_struct, 'subName')
                subject_name = data_struct.subName;
            else
                [~, subject_name] = fileparts(files(i).name);  % Use filename without extension
            end
            
            % Extract confidence data if available
            if isfield(data_struct, 'conf')
                conf_data = data_struct.conf;
                
                % Ensure confidence data is in proper format
                if iscell(conf_data)
                    conf_data = cell2mat(conf_data);  % Convert cell array to matrix
                end
                
                % Trim to match number of trials
                conf_data = conf_data(1:min(num_trials, numel(conf_data)));
                subject_confidences(subject_name) = conf_data;
                fprintf('Subject: %s, Confidence data loaded for %d trials\n', subject_name, numel(conf_data));
            else
                warning('Missing conf field in data for file: %s', file_path);
                subject_confidences(subject_name) = nan(1, num_trials);  % Mark as missing data
            end
        catch ME
            warning('Failed to load behavioral data: %s\nError: %s', file_path, ME.message);
        end
    end

    %% Load stimulus images
    fprintf('\n==== IMAGE LOADING ====\n');
    files_img = dir(fullfile(img_address, "*.png"));  % Find all PNG files
    fprintf('Found %d PNG files\n', numel(files_img));
    
    Images = cell(num_trials, 1);  % Preallocate image storage
    
    % Load up to num_trials images
    for i = 1:min(num_trials, numel(files_img))
        img_path = fullfile(img_address, files_img(i).name);  % Full image path
        fprintf('Loading image %d: %s\n', i, img_path);
        
        try
            img = imread(img_path);  % Read image file
            Images{i} = img;         % Store in cell array
        catch ME
            warning('Failed to load image: %s\nError: %s', img_path, ME.message);
            Images{i} = [];  % Mark as empty if load fails
        end
    end

    %% Process each subject
    for s_idx = 1:numel(subjects)
        subject = subjects{s_idx};  % Current subject
        fprintf('\n==== PROCESSING SUBJECT: %s ====\n', subject);
        
        % Create subject-specific output folder
        output_folder = fullfile(base_output_folder, subject);
        if ~exist(output_folder, 'dir')
            mkdir(output_folder);  % Create folder if it doesn't exist
        end

        % Preallocate arrays for metrics
        total_durations = zeros(num_trials, 1);  % Total fixation duration per trial
        confidence_values = nan(num_trials, 1);  % Confidence values per trial
        
        % Get confidence data for current subject
        subject_found = false;
        all_keys = subject_confidences.keys;  % All available subject names
        
        % Case-insensitive matching for subject name
        for k = 1:numel(all_keys)
            if strcmpi(all_keys{k}, subject)
                confidence_data = subject_confidences(all_keys{k});
                subject_found = true;
                fprintf('Using confidence data for: %s\n', all_keys{k});
                break;
            end
        end
        
        if ~subject_found
            warning('No confidence data found for subject: %s', subject);
            confidence_data = nan(1, num_trials);  % Fill with NaNs
        end

        % Construct EDF file path
        edf_file = fullfile(edfDir, [subject '.edf']);
        fprintf('EDF Path: %s\n', edf_file);
        
        % Skip if EDF file doesn't exist
        if ~exist(edf_file, 'file')
            warning('EDF file not found!');
            continue;
        end

        % Load EDF data
        try
            fprintf('Loading EDF data...\n');
            edf = Edf2Mat(edf_file);  % Parse EDF file
            fprintf('EDF loaded successfully\n');
        catch ME
            warning('EDF loading failed: %s', ME.message);
            continue;  % Skip to next subject
        end

        %% Extract fixation data
        if ~isfield(edf.Events, 'Efix') || isempty(edf.Events.Efix)
            warning('No fixation data found!');
            continue;  % Skip if no fixations
        else
            fprintf('Found fixation data\n');
        end
        
        % Get screen resolution from EDF
        try
            screen_width = edf.Recordings{1}.screen.x;
            screen_height = edf.Recordings{1}.screen.y;
            fprintf('Screen resolution: %dx%d\n', screen_width, screen_height);
        catch
            % Use defaults if resolution not found
            screen_width = 1920;
            screen_height = 1080;
            fprintf('Using default resolution: %dx%d\n', screen_width, screen_height);
        end
        
        % Extract fixation metrics
        fixations = edf.Events.Efix;
        fixX = [fixations.posX];         % X positions
        fixY = [fixations.posY];         % Y positions
        fixDurs = [fixations.duration];  % Durations (ms)
        fixStarts = [fixations.start];   % Start times
        fprintf('Total fixations: %d\n', numel(fixX));

        %% Extract trial times
        [timesStim, actual_trials] = get_trial_times(edf, num_trials);
        
        if isempty(timesStim)
            warning('No valid trial markers found!');
            continue;  % Skip if no valid trials
        else
            fprintf('Found %d valid trials\n', actual_trials);
        end

        %% Process each trial
        trial_colors = lines(actual_trials);  % Get distinct colors for actual trials

        for trial = 1:actual_trials
            fprintf('\nProcessing TRIAL %d/%d\n', trial, actual_trials);
            
            % Create invisible figure
            fig = figure('Visible', 'off', 'Position', [100 100 1200 800]);
            
            % Display stimulus image for this trial
            [img, img_height, img_width] = display_stimulus(Images, trial, screen_width, screen_height);
            hold on;  % Allow overlaying fixations
            
            % Get fixations within this trial's time window
            [trial_fixX, trial_fixY, trial_durations] = get_trial_fixations(...
                fixX, fixY, fixDurs, fixStarts, timesStim, trial);
            fprintf('Fixations in trial: %d\n', numel(trial_fixX));
            
            % Mirror Y coordinates (eye tracker vs image coordinate system)
            if ~isempty(trial_fixY)
                midline = img_height / 2;
                trial_fixY = 2 * midline - trial_fixY;  % Mirror around midline
            end
            
            % Get this trial's base color
            base_color = trial_colors(trial, :);
            
            % Calculate total fixation duration for this trial
            trial_total_duration = 0;
            
            % Process fixations if any exist
            if ~isempty(trial_fixX)
                % Filter by duration
                valid_idx = (trial_durations >= min_duration);
                trial_fixX = trial_fixX(valid_idx);
                trial_fixY = trial_fixY(valid_idx);
                trial_durations = trial_durations(valid_idx);
                fprintf('Valid fixations after filtering: %d\n', numel(trial_fixX));
                
                % Calculate total fixation duration
                trial_total_duration = sum(trial_durations);
                
                % Plot circles if valid fixations remain
                if ~isempty(trial_fixX)
                    plot_fixation_circles(trial_fixX, trial_fixY, trial_durations, ...
                        min_radius, max_radius, min_duration, max_duration, circle_alpha, base_color);
                end
            end
            
            % Store total duration for this trial
            total_durations(trial) = trial_total_duration;
            
            % Store confidence value for this trial
            if trial <= numel(confidence_data)
                confidence_values(trial) = confidence_data(trial);
            else
                confidence_values(trial) = nan;
            end
            
            % Add title with subject, trial, confidence, and total duration
            title_str = sprintf('Subject: %s | Trial: %d | Conf: %.1f | Total Duration: %d ms', ...
                subject, trial, confidence_values(trial), trial_total_duration);
            title(title_str, 'FontSize', 12, 'FontWeight', 'bold');
            
            % Save figure
            output_path = fullfile(output_folder, sprintf('%s_Trial_%d_Fixation_Duration.png', subject, trial));
            saveas(fig, output_path);
            fprintf('Saved: %s\n', output_path);
            close(fig);  % Close figure to free memory
        end
        
        %% Generate and save confidence vs total duration plot
        generate_duration_confidence_plot(total_durations, confidence_values, subject, duration_output_folder);
    end
    
    fprintf('\n==== PROCESSING COMPLETE ====\n');
    
    %% Nested Helper Functions
    
    function [timesStim, actual_trials] = get_trial_times(edf, num_trial)
        % Extracts start/end times for each trial from EDF messages
        fprintf('\n--- EXTRACTING TRIAL TIMES ---\n');
        
        all_messages = edf.Events.Messages.info;  % Event messages
        all_times = edf.Events.Messages.time;     % Event timestamps
        
        % Debug: Print first 10 messages
        fprintf('First 10 messages:\n');
        for i = 1:min(10, numel(all_messages))
            fprintf('%d: %s\n', all_times(i), all_messages{i});
        end
        
        % Define possible start/end markers
        start_markers = {'TRIAL_START', 'StartFixation', 'STIMULUS_ON'};
        end_markers = {'TRIAL_END', 'EndAnswer', 'STIMULUS_OFF'};
        
        start_indices = [];
        end_indices = [];
        
        % Find start markers
        for m = 1:length(start_markers)
            start_indices = find(contains(all_messages, start_markers{m}));
            if ~isempty(start_indices)
                fprintf('Found start markers: %s\n', start_markers{m});
                break;
            end
        end
        
        % Find end markers
        for m = 1:length(end_markers)
            end_indices = find(contains(all_messages, end_markers{m}));
            if ~isempty(end_indices)
                fprintf('Found end markers: %s\n', end_markers{m});
                break;
            end
        end
        
        % Error handling if markers not found
        if isempty(start_indices) || isempty(end_indices)
            warning('No start/end markers found!');
            timesStim = [];
            actual_trials = 0;
            return;
        end
        
        % Handle marker count mismatch
        if numel(start_indices) ~= numel(end_indices)
            warning('Marker count mismatch: %d starts, %d ends', ...
                numel(start_indices), numel(end_indices));
        end
        
        % Determine actual number of trials
        actual_trials = min(num_trial, numel(start_indices));
        timesStim = [all_times(start_indices(1:actual_trials));...
                     all_times(end_indices(1:actual_trials))].';  % Nx2 matrix
        
        fprintf('Extracted %d trials\n', actual_trials);
    end

    function [img, img_height, img_width] = display_stimulus(Images, trial, screen_width, screen_height)
        % Displays stimulus image or blank canvas if image unavailable
        if ~isempty(Images) && numel(Images) >= trial && ~isempty(Images{trial})
            img = Images{trial};  % Get trial image
            img = flipud(img);    % Correct vertical orientation
            [img_height, img_width, ~] = size(img);  % Get dimensions
            himg = imshow(img);   % Display image
            set(himg, 'AlphaData', img_alpha);  % Set transparency
            axis normal;           % Maintain aspect ratio
            set(gca, 'YDir', 'normal');  % Correct Y-axis direction
        else
            % Create blank canvas if image unavailable
            img = ones(screen_height, screen_width, 3);  % White background
            img = flipud(img);  % Correct orientation
            img_height = screen_height;
            img_width = screen_width;
            imshow(img);
            axis normal;
            set(gca, 'YDir', 'normal');
            fprintf('    Using blank canvas for trial %d: %dx%d\n', trial, screen_width, screen_height);
        end
    end

    function [trial_fixX, trial_fixY, trial_durations] = get_trial_fixations(...
            fixX, fixY, fixDurs, fixStarts, timesStim, trial)
        % Extracts fixations within a specific trial's time window
        % Create logical index for fixations within trial timeframe
        fix_idx = (fixStarts >= timesStim(trial, 1)) & (fixStarts <= timesStim(trial, 2));
        
        % Return filtered fixations
        trial_fixX = fixX(fix_idx);
        trial_fixY = fixY(fix_idx);
        trial_durations = fixDurs(fix_idx);
        
        fprintf('    Trial %d: %d fixations before filtering\n', trial, sum(fix_idx));
    end

    function plot_fixation_circles(trial_fixX, trial_fixY, trial_durations, ...
        min_radius, max_radius, min_duration, max_duration, circle_alpha, base_color)
        % Plots fixation circles with size and color intensity based on duration
    
        % Filter by duration range
        valid_idx = (trial_durations >= min_duration) & (trial_durations <= max_duration);
        trial_fixX = trial_fixX(valid_idx);
        trial_fixY = trial_fixY(valid_idx);
        trial_durations = trial_durations(valid_idx);
        
        if isempty(trial_fixX)
            return;  % Exit if no valid fixations
        end
        
        % Normalize durations to [0,1] range
        norm_durations = (trial_durations - min_duration) / (max_duration - min_duration);
        norm_durations = max(0, min(1, norm_durations));  % Clamp values
        
        % Plot each fixation
        for k = 1:length(trial_fixX)
            % Calculate circle size based on duration
            radius = min_radius + (max_radius - min_radius) * norm_durations(k);
            
            % Calculate color intensity (darker for longer fixations)
            intensity_factor = 0.4 + 0.6 * norm_durations(k);  % Range: 40%-100%
            color = base_color * intensity_factor;  % Scale base color
            
            % Draw circle
            rectangle('Position', [trial_fixX(k)-radius, trial_fixY(k)-radius, 2*radius, 2*radius], ...
                'Curvature', [1 1], ...          % Makes it a circle
                'FaceColor', [color circle_alpha], ... % Fill color with transparency
                'EdgeColor', color * 0.8, ...     % Slightly darker border
                'LineWidth', 2);                  % Border thickness
            
            % Add duration text for larger circles
            if radius >= 20
                text(trial_fixX(k), trial_fixY(k), sprintf('%d', trial_durations(k)), ...
                    'HorizontalAlignment', 'center', ...
                    'VerticalAlignment', 'middle', ...
                    'Color', 'white', ...          % White text for contrast
                    'FontSize', 10, ...
                    'FontWeight', 'bold');
            end
        end
    end

    function generate_duration_confidence_plot(total_durations, conf_values, subject, output_folder)
        % Creates scatter plot of total fixation duration vs confidence
        
        % Filter out invalid trials
        valid_idx = ~isnan(conf_values) & ~isnan(total_durations);
        total_durations = total_durations(valid_idx);
        conf_values = conf_values(valid_idx);
        
        if isempty(conf_values) || numel(conf_values) < 2
            warning('Insufficient confidence data for subject %s', subject);
            return;
        end
        
        % Create figure
        fig = figure('Position', [100 100 800 600], 'Visible', 'off');
        
        % Create scatter plot with jitter
        jitter = 0.1 * randn(size(conf_values));  % Small jitter for visibility
        scatter(conf_values + jitter, total_durations, 100, 'filled', ...
            'MarkerFaceColor', [0.2 0.6 0.3], ...  % Green color for duration
            'MarkerEdgeColor', 'k');
        
        % Add labels and title
        xlabel('Confidence Rating');
        ylabel('Total Fixation Duration (ms)');
        title(sprintf('Fixation Duration vs Confidence: %s', subject));
        grid on;
        
        % Calculate and plot linear regression
        hold on;
        p = polyfit(conf_values, total_durations, 1);
        x_fit = linspace(min(conf_values), max(conf_values), 100);
        y_fit = polyval(p, x_fit);
        plot(x_fit, y_fit, 'r-', 'LineWidth', 2);
        
        % Calculate correlation
        [r, p_val] = corrcoef(conf_values, total_durations);
        r_value = r(1,2);
        p_value = p_val(1,2);
        
        % Add correlation info
        text(0.05, 0.95, sprintf('r = %.2f\np = %.3f', r_value, p_value), ...
            'Units', 'normalized', ...
            'FontSize', 12, ...
            'BackgroundColor', [1 1 1 0.7]);
        
        % Add legend
        legend('Trial Data', 'Linear Fit', 'Location', 'best');
        
        % Set axis limits
        xlim([min(conf_values)-0.5, max(conf_values)+0.5]);
        
        % Save plot
        output_path = fullfile(output_folder, sprintf('%s_Duration_vs_Confidence.png', subject));
        saveas(fig, output_path);
        fprintf('Saved duration-confidence plot: %s\n', output_path);
        close(fig);
    end
end